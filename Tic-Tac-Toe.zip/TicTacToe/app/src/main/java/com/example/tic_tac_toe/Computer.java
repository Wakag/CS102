package com.example.tic_tac_toe;

import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;
public class Computer extends AppCompatActivity {
    private String Icon;
    private int position;
    private int Icon_num;

}
